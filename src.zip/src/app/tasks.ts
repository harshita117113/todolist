
export class tasks{
  constructor(
    public id: number,
    public title: string,
    public isCompleted?: boolean | null
  ){ }
}
